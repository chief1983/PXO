(this txt is best viewed in 1024x768)

This will file contains the changes to Squad War MT (1,2,3,5,mal_final) missions, 4 new NWTRs,
and two new missions.
(Note all other MT missions in the Mission.txt are fine but the Description of MT-02 
(Mentu Duel) is wrong on the Squad war page, the new Description is in the file as well
any comments may be sent to malboeuf@westman.wave.ca



                                    Contents of mission-updates.zip
                                    ************************

  MT-02c.fs2	(Mentu Duel)		this is the Revised mission for MT-02
  MT-03c.fs2	(Deimos Duel)		this is the Revised mission for MT-03
  MT-05a.fs2	(Close Quarters)	this is the Revised mission for MT-05
  MAL-SDd.fs2	(Sobek Duel)		this is the Revised mission for mal-final.fs2
  MT-11.fs2	(Aeolus Duel 2)		New Squad War Mission (based on Aeolus Duel)
  MT-12.fs2	(Fighter Mayhem)	New Squad War Mission (based on NWTR)
  MT-13.fs2	(Bomber Mayhem)		New Squad War Mission (based on NWTR)
  MT-14.fs2	(Aspect Lock)		New Squad War Mission (based on NWTR)
  MT-15.fs2	(Primary Mayhem)	New Squad War Mission (based on NWTR)
  MT-16.fs2	(Stealth vs. Awac 2)	New Squad War Mission (based on Stealth vs. Awacs - MT-08)
  MAL-ST.fs2	(Stealth Tag)		New Squad War Mission
  gldm-HnS	(Hide and Seek)		New Squad War Mission


